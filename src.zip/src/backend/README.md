# MAVSDK with GRPC

### Build with backend

```
make BUILD_BACKEND=YES
```

### Run the backend

The backend is built as an executable:

```
./build/default/backend/src/backend_bin
```
