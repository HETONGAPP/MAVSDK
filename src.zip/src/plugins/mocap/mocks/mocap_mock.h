#include <gmock/gmock.h>

#include "plugins/mocap/mocap.h"

namespace mavsdk {
namespace testing {

class MockMocap {
public:
    // TODO
};

} // namespace testing
} // namespace mavsdk
