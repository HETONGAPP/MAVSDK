#include <gmock/gmock.h>

#include "plugins/shell/shell.h"

namespace mavsdk {
namespace testing {

class MockShell {
public:
    // TODO
};

} // namespace testing
} // namespace mavsdk