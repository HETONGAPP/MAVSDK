# -*- coding: utf-8 -*-
""" Autogenerator for MAVSDK """


from .autogen import AutoGen
